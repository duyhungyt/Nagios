#!/usr/bin/perl
use strict;
use CGI;
use Data::Dumper qw(Dumper);

my $querry = new CGI;
my $selected = $querry->param('selected');
my $file = $querry->param('file');
my $host = $querry->param('host');
my $add = $querry->param('add');
my $service_name = $querry->param('service_name');
my $service_command = $querry->param('service_command');
my $service_more = $querry->param('service_more');
my $save = $querry->param('save');
my $cancel = $querry->param('cancel');
my $command;

my $temp = $file.".tmp";
my $new_service = "\ndefine service {
    use                     local-service
    host_name               $host
    service_description     $service_name
    check_command           $service_command
    $service_more
}\n";

if ($add ne ""){
    my @content;
    my $check = 0;
    if (open(my $f, "<", "/usr/local/nagios/etc/my_config/$temp")){
        @content = <$f>;
        foreach my $line (@content){
            if ($line =~ /$service_name/ || $line =~ /$service_command/){
                $check = 1;
                last;
            }
        }
        close($f);
    }
    if (open(my $f, "<", "/usr/local/nagios/etc/my_config/$file")){
        @content = <$f>;
        foreach my $line (@content){
            if ($line =~ /$service_name/ || $line =~ /$service_command/){
                $check = 1;
                last;
            }
        }
        close($f);
    }
    if ($check == 0){
        if (open(my $f, ">>", "/usr/local/nagios/etc/my_config/$temp")){
            print $f $new_service;
            close($f);
        }
    }
}

print "Content-type: text/html\n\n";
print '<html>';

if ($cancel ne ""){
    my $cmd = "rm /usr/local/nagios/etc/my_config/$temp";
    $cmd = `$cmd`;
    print '<meta http-equiv="refresh" content="0; URL=add-service.pl?host='.$host.'&file='.$file.'">';
}

if ($save ne ""){
    open(DATA1, "</usr/local/nagios/etc/my_config/$temp");
    open(DATA2, ">>/usr/local/nagios/etc/my_config/$file");
    while (<DATA1>){
        print DATA2 $_;
    }
    close(DATA1);
    close(DATA2);
    my $cmd = "rm /usr/local/nagios/etc/my_config/$temp";
    $cmd = `$cmd`;
    $cmd = `sudo systemctl restart nagios`;
    print '<meta http-equiv="refresh" content="0; URL=delete-service.pl">';
}

print '<head>';
print '<script type="text/javascript">
        function selected_service(url) {
            var val = document.getElementsByName("select");
            this.location = url + "&selected=" + val[0].value;
        };
        function add_service(url) {
            var name = document.getElementById("service_name").value;
            var command = document.getElementById("service_command").value;
            var more = document.getElementById("more").value;
            if (name == "" || command == ""){
                alert("Error");
            }else{
                this.location = url + "&service_name=" + name + "&service_command=" + command + "&service_more=" + more + "&add=1";
            }
        };
        function save(url){
            if (confirm("Xac nhan them service vao file config")){
                this.location = url + "&save=1";
            }
        };
        function cancel(url){
            if (confirm("Xac nhan huy them service")){
                this.location = url + "&cancel=1";
            }
        };
    </script>';
print '<style>
    div     {float:left;}
    div.col {min-height:100%;}
    div.row {width:100%;}
    div.content {border-width:1px; border-style: solid; text-align:left; padding:15px; width:90%; margin-bottom:15px;}
    input {width:100%;}
    table {width:100%; font-size:13px;}
    select {font-size:13px;}
</style>';
print '</head>';
print '<body style="height: auto; min-height: 100%; font-size:13px;">';
print '<div style="width:50%" class="col">';
#khoi ben trai
    print '<div class="row">';
        print '<div class="content">';
        print '<table>';
        print '<tr><td>Host</td><td><input type="text" value="'.$host.'" disabled></td></tr>';
        print '<tr><td>File config</td><td><input type="text" value="'.$file.'" disabled></td></tr>';
        print '</table>';
        print '</div>';
    print '</div>';
    print '<div class="row"  style="min-height:100%; border-width:1px; border-style:solid; padding:5px; width: 94%;">';
        print '<div style="width:35%" class="col">';
        print '<h4 style="margin: auto;">List service</h4>';
        print '<select name="select" multiple style="height:350px; width:90%; margin-top: 15px;" onchange="selected_service(\'add-service.pl?host='.$host.'&file='.$file.'\')">';
        if (open(my $f ,"<", "/usr/local/nagios/etc/objects/commands.cfg")){
            my $check = 0;
            my $command_name;
            my $command_line;
            foreach my $line (<$f>){
                my @word = split /[ ]{2,}/, $line, 3;
                if ($line =~ /define command/){
                    $check = 1;
                }
                if ($check == 1){
                    if ($line =~ /command_name/){
                        $command_name = @word[2];
                    }
                    if ($line =~ /command_line/){
                        $command_line = @word[2];
                        if ($command_line !~ /printf/ && $command_name !~ /check-host-alive/){
                            if ($command_name =~ /$selected/){
                                print '<option value="'.$command_name.'" selected>'.$command_name.'</option>';
                                $command = $command_line;
                            }
                            else{
                                print '<option value="'.$command_name.'">'.$command_name.'</option>';
                            }
                        }
                        $check = 0;
                    }
                }
            }
            close($f);
        }
        print '</select>';
        print '</div>';
        print '<div style="width:65%" class="col">';
            print '<div class="row">';
            print '<h4 style="margin:auto">Comnand and example</h4>';
            print '<div style="width:85%; height:100px; padding:20px">';
            if ($selected ne ""){
                print $selected.'<br><br>';
                print substr($command,8);
            }
            print '</div>';
            print '</div>';
            print '<div style="width:100%">';
            print '<h4>Add service</h4>';
            print '<table width="100%">';
            print '<tr><td>define service { </td></tr>';
            print '<tr><td>&#160;use</td><td>local-service</td></tr>';
            print '<tr><td>&#160;host_name</td><td>'.$host.'</td></tr>';
            print '<tr><td>&#160;service_description</td><td><input id="service_name" type="text" value="'.$service_name.'"></td></tr>';
            print '<tr><td>&#160;check_command</td><td><input id="service_command" type="text" value="'.$service_command.'"></td></tr>';
            print '<tr><td colspan="2"><textarea id="more" style="width:100%; resize: vertical;" rows="1">'.$service_more.'</textarea></td></tr>';
            print '<tr><td>}</td></tr>';
            print '<tr><td></td><td style="text-align:right"><input style="width:auto" type="button" onclick="add_service(\'add-service.pl?host='.$host.'&file='.$file.'&selected='.$selected.'\')" value="Add"></td></tr>';
            print '</table>';
            print '</div>';
        print '</div>';
    print '</div>';
print '</div>';
print '<div style="width:48%; padding:5px; border-width:1px; border-style:solid;" class="col">';
print '<h4>Review file config<h4>';
print '<table>';
if (open(my $f, "<", "/usr/local/nagios/etc/my_config/$file")){
    my @content = <$f>;
    foreach my $line (@content){
        if ($line =~ /^define/ || $line =~ /}$/){
            print '<tr><td>'.$line.'</td></tr>';
        }else{
            my @word = split /[ ]{2,}/, $line, 3;
            print '<tr><td>&emsp;&emsp;'.@word[1].'</td><td>'.@word[2].'</td></tr>';
        }
    }
    close($f)
}
my $check_new = 0;
if (open(my $f, "<", "/usr/local/nagios/etc/my_config/$temp")){
    $check_new = 1;
    my @content = <$f>;
    foreach my $line (@content){
        if ($line =~ /^define/ || $line =~ /}$/){
            print '<tr><td style="color:red;">'.$line.'</td></tr>';
        }else{
            my @word = split /[ ]{2,}/, $line, 3;
            print '<tr><td style="color:red;">&emsp;&emsp;'.@word[1].'</td><td style="color:red;">'.@word[2].'</td></tr>';
        }
    }
    close($f);
}
print '<tr><td></td><td style="text-align:right"><input style="width:auto" type="button" onclick="cancel(\'add-service.pl?host='.$host.'&file='.$file.'\')" value="Cancel" '.(($check_new == 1)? "":"disabled").'><input style="width:auto" type="button" onclick="save(\'add-service.pl?host='.$host.'&file='.$file.'\')" value="Save" '.(($check_new == 1)? "":"disabled").'></td></tr>';
print '</table>';
print '</div>';

print '</body></html>';