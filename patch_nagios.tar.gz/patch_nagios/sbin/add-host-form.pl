#!/usr/bin/perl
use strict;
use CGI;

my $link_target = 'review';
my $query = new CGI;
my $selected_type = $query->param('selected');
my $host_name = $query->param('host_name');
my $address = $query->param('address');
my $alias = $query->param('alias');
my $group = $query->param('group');

#Form nhap thong tin
print "Content-type: text/html\n\n";
print '<html>';
print '<head>
        <script type="text/javascript">
            function set_selected(url) { 
                url = url + "\?host_name=" + document.getElementById("host_name").value + "\&address=" + document.getElementById("address").value + "\&alias=" + document.getElementById("alias").value + "\&group=" + document.getElementById("group").value;
                this.location = url + "\&selected=" + document.getElementById("type").value;
            }
        </script>
        </head>';
print '<body class="config">';
print '<div style="width:100%;  float:left">';
print '<FORM action="save-host.pl" target="'.$link_target.'" method = "GET" >';
print '<div align = "center" style = "width:100%">';
print '<table style="width:90%; padding:10px 10px;">';
print '<tr>';
print '<td>Type</td>';
print '<td><select id="type" name="type" onchange="set_selected(\'add-host-form.pl\')">';
if ($selected_type eq "server" || $selected_type eq ""){
    print '<option value = "server" selected>Server</option>';
    $group = "linux-servers";
}else{
    print '<option value = "server">Server</option>';
}
if ($selected_type eq "switch"){
    print '<option value = "switch" selected>Switch</option>';
    $group = "switchs";
}else{
    print '<option value = "switch">Switch</option>';
}
if ($selected_type eq "router"){
    print '<option value = "router" selected>Router</option>';
    $group = "routers";
}else{
    print '<option value = "router">Router</option>';
}
if ($selected_type eq "unknow"){
    print '<option value = "unknow" selected>Unknow</option>';
    $group = "unknows";
}else{
    print '<option value = "unknow">Unknow</option>';
}

print '</select></td>';
print '</tr>';
print '<td>Host name</td>';
print '<td><input type = "text" id = "host_name" name = "host_name" value="'.$host_name.'"></td>';
print '</tr>';
print '<tr>';
print '<td>Alias</td>';
print '<td><input type = "text" id = "alias" name = "alias" value = "'.$alias.'"></td>';
print '</tr>';
print '<tr>';
print '<td>Address</td>';
print '<td><input type = "text" id = "address" name = "address" value = "'.$address.'"></td>';
print '</tr>';
print '<tr><td>Group</td><td><select id = "group" name = "group">';
#load hien cac tuy chon group ~ template
print '<option value="linux-servers" '.(($group =~ "linux-servers")? "selected":"").'>Linux Servers</option>';
print '<option value="window-servers" '.(($group =~ "window-servers")? "selected":"").'>Window Servers</option>';
print '<option value="switchs" '.(($group =~ "switchs")? "selected":"").'>Network Switchs</option>';
print '<option value="routers" '.(($group =~ "routers")? "selected":"").'>Network Routers</option>';
print '<option value="unknows" '.(($group =~ "unknows")? "selected":"").'>Unknows</option>';
print '</select></td>';
print '</tr>';
print '<tr>';
print '<td><input type = "submit" value = "Create"></td>';
print '</tr>';
print '</table>';
print '</div>';
print '</FORM>';
print '</div>';
print '<div>';
#hien thi cac service theo nhom thiet bi

print '</div>';