#!/usr/bin/perl
use strict;
use CGI;

my $querry = new CGI;
my $delete = $querry->param('delete');
my $host = $querry->param('host');

print "Content-type: text/html\n\n";
print '<html>';
print '<head>';
print '<script type="text/javascript">
        function delete_service(service, host) {
            if (confirm("Xac nhan xoa service " + service + " khoi " + host)){
                this.location = this.location + "?delete=" + service + "&host=" + host;
            } 
        };
        function add_service(host,file){
            this.location = "./add-service.pl?host=" + host + "&file=" +file;
        }
    </script>';
print '<style>
        table.data    { padding: 0; }
        th.data       { font-size: 12pt; text-align: left; padding: 0 3px 0 3px; border-bottom: 1px solid #777777; color: #333333; }
        .dataOdd      { font-size: 10pt; background-color: #e7e7e7; padding: 0px 4px 0px 4px; }
        .dataEven     { font-size: 10pt; background-color: #f4f2f2; padding: 0px 4px 0px 4px; }
        a             { text-decoration: none;}
    </style>';
print '</head>';
print '<body>';

if ($delete ne "" && $host ne ""){
    #delete service
    if (open(my $fdel, "<", "/usr/local/nagios/etc/my_config/$host")){
        my @content = <$fdel>;
        #print @content;
        my $length =0;
        my $offset = 0;
        my $count = 0;
        my $check = 0;
        foreach my $line (@content){
            chomp($line);
            if ($delete eq substr($line,28)){
                $offset = $count;
                $check = 1;
            }
            if ($line =~ /service_description/ && $delete ne substr($line,28) && $check == 1){
                $length = $count - $offset;
                $check = 0;
                last;
            }
            $count++;
        }
        if ($length == 0){
            $length = $count - $offset;
            splice @content, $offset, $length;
            while (@content[$offset] !~ /}/){
                splice @content, $offset, 1;
                $offset--;
            }
        }else{
            splice @content, $offset, $length;
        }
        close($fdel);
        if (open(my $fdel, ">", "/usr/local/nagios/etc/my_config/$host")){            
            foreach my $l (@content){
                chomp($l);
                print $fdel "$l\n";
            }
            my $cmd = `sudo systemctl restart nagios`;
            print '<meta http-equiv="refresh" content="0; URL=delete-service.pl">';
            close($fdel);
        }else{
            print "dfkgjkelrjht";
        }
    }
}else{
    ##show danh sach service
    print '<table width="100%" align="center" class="data">';
    print '<tr><th class="data">Host</th><th class="data">Service</th><th class="data">Command</th><th class="data">File config</th><th class="data"></th></tr>';

    if (open (my $f, "<", "/usr/local/nagios/var/objects.cache")){
        my $check = 0;
        my $even = 0;
        my ($hostname, $service, $command, $file);
        while (my $line = <$f>){
            if ($check == 1){
                if ($line =~ /host_name/)
                {
                    $hostname = substr($line, 11);
                    chomp($hostname);
                    my $cmd = 'ls /usr/local/nagios/etc/my_config/*'.$hostname.'.cfg';
                    $cmd = `$cmd`;
                    if ($cmd ne ""){
                        $file = substr($cmd,32);
                        chomp($file);
                        print '<tr class="'.(($even % 2)? "dataEven":"dataOdd").'">';
                        print '<td class="'.(($even % 2)? "dataEven":"dataOdd").'"><a href="extinfo.cgi?type=1&host='.$hostname.'">'.$hostname.'</td>';
                        print '<td></td><td></td>';
                        print '<td class="'.(($even % 2)? "dataEven":"dataOdd").'">'.(($file eq "")? "Unlocated":$file).'</td>';
                        print '<td align = "left"><input type = "button" value = "Add new service" onclick="add_service(\''.$hostname.'\',\''.$file.'\')" '.(($file eq "")? "disabled":"").'></td>';
                        print '</tr>';
                        $even = ($even + 1) % 2;
                        if (open(my $fcon, "<", "/usr/local/nagios/etc/my_config/$file")){
                            my $checkser=0;
                            while (my $linecon = <$fcon>){
                                if ($linecon =~ /define service/){
                                    $checkser = 1;
                                }
                                if ($checkser == 1){
                                    if ($linecon =~ /service_description/){
                                        $service = substr($linecon,28);
                                        chomp($service);
                                    }
                                    if ($linecon =~ /check_command/){
                                        $command = substr($linecon,28);
                                        chomp($command);
                                        $checkser = 0;
                                        print '<tr class="'.(($even % 2)? "dataEven":"dataOdd").'">';
                                        print '<td style="background-color:white"></td>';
                                        print '<td class="'.(($even % 2)? "dataEven":"dataOdd").'"><a href="extinfo.cgi?type=2&host='.$hostname.'&service='.$service.'">'.$service.'</td>';
                                        print '<td class="'.(($even % 2)? "dataEven":"dataOdd").'">'.$command.'</td>';
                                        print '<td></td>';
                                        print '<td align = "right"><input type = "button" value = "Delete" onclick="delete_service(\''.$service.'\',\''.$file.'\')" '.(($service eq "PING")? "disabled":"").'></td>';
                                        print '</tr>';
                                        $even = ($even + 1) % 2;
                                    }
                                }
                            }
                        }
                    }
                    $check = 0;
                }
            }
            if ($line =~ /define host/){
                $check = 1;
            }
        }
    }

    print '</table>';
}