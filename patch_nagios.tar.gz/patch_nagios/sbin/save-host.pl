#!/usr/bin/perl
use strict;
use CGI;

my $query = new CGI;
my $issave = $query->param('save');

print "Content-type: text/html\n\n";
print '<html>';
print '<head>
        <script type="text/javascript">
            function save() {
                this.location = this.location + "\&save=1";
            }
        </script>
    </head>';
print '<body>';
print '<div style="width:100%; height:100%">';

#Khai bao bien
my $host_name = $query->param('host_name');
my $address = $query->param('address');
my $alias = $query->param('alias');
my $type = $query->param('type');
my $group = $query->param('group');
my $save = $query->param('save');
chomp($host_name);
chomp($address);
chomp($alias);
my @list_host;
my $file;
my $template;
#lay danh sach host da co
if (open (my $f, "<", "/usr/local/nagios/var/objects.cache")){
    my $check = 0;
    while (my $line = <$f>){
        if ($check ==1 && $line =~ /host_name/){
            my $name = substr($line, 11);
            chomp($name);
            push @list_host, $name;
            $check = 0;
        }
        if ($line =~ /define host/){
            $check = 1;
        }
    }
}

#kiem tra thong tin file config
if (($host_name ne "") && ($alias ne "") && ($address ne "")){
    if ($host_name ~~ @list_host){
        print '<div style="text-align:center; parding:10px;">';
        print '<span style="font-size:20px; font-weight: bold; color:red;">ERROR!!!&emsp;<span style="color:black;">'.$host_name.'</span>is available!!!</span>';
        print '</div>';
    }else{

        #Thiet lap ten file config
        if ($type =~ "server"){
            $file = "server_".$host_name.'.cfg';
        }elsif ($type =~ "switch") {
            $file = "switch_".$host_name.'.cfg';
        }elsif ($type =~ "router") {
            $file = "router_".$host_name.'.cfg';
        }else{
            $file = "unknow_".$host_name.'.cfg';
        }
        
        #template va group
        if ($group =~ "linux-servers"){
            $template = "linux-server";
        }elsif ($group =~ "window-servers"){
            $template = "window-server";
        }elsif ($group =~ "switchs"){
            $template = "generic-switch";
        }elsif ($group =~ "routers"){
            $template = "generic-router";
        }else{
            $template = "unknow";
        }

        #File config
my $myconten = "define host {
    use                     $template            
    host_name               $host_name
    alias                   $alias
    address                 $address
    hostgroups              $group
}

define service {
    use                     local-service
    host_name               $host_name
    service_description     PING
    check_command           check_ping!100.0,20%!500.0,60%
}";
        
        #review file config
        print 'Review file config:   '.$file.'<br><br>';
        print '<table style="width:100%">';
        print '<tr><td>define host {</td></tr>';
        print '<tr><td>&emsp;use</td>                     <td>'.$template.'</td></tr>';
        print '<tr><td>&emsp;host_name</td>               <td>'.$host_name.'</td></tr>';
        print '<tr><td>&emsp;alias</td>                   <td>'.$alias.'</td></tr>';
        print '<tr><td>&emsp;address</td>                 <td>'.$address.'</td></tr>';
        print '<tr><td>&emsp;hostgroups</td>                 <td>'.$group.'</td></tr>';
        print '<tr><td>}</td></tr>';
        print '<tr><td>define service {</td></tr>';
        print '<tr><td>&emsp;use</td>                     <td>local-service</td></tr>';
        print '<tr><td>&emsp;host_name</td>               <td>'.$host_name.'</td></tr>';
        print '<tr><td>&emsp;service_description</td>     <td>PING</td></tr>';
        print '<tr><td>&emsp;check_command</td>           <td>check_ping!100.0,20%!500.0,60%</td></tr>';
        print '<tr><td>}</td></tr>';
        print '<tr><td></td><td align="right"><input type="button" value="Save" onclick="save()"></td></tr>';
        print '</table>';

        if ($save eq "1"){
        #luu file config
            if (open (my $f, ">", "/usr/local/nagios/etc/my_config/$file")){
                print $f $myconten;
                my $cmd = `sudo systemctl restart nagios`;
            }
            print '<meta http-equiv="refresh" content="0; URL=save-host.pl">';
        }
    }
}else{
    print '<meta http-equiv="refresh" content="0; URL=delete-host.pl">';
}
print '</div>';

print '</body>';
print '</html>';