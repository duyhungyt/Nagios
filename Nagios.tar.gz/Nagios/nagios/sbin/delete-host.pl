#!/usr/bin/perl
use strict;
use CGI;
use Class::Struct;

struct host =>
{
    host_name => '$',
    alias => '$',
    address => '$',
    type => '$',
    file => '$'
};

my $query = new CGI;
my $delete = $query->param('delete');

print "Content-type: text/html\n\n";
print '<html>';
print '<head>';
print '<script type="text/javascript">
        function delete_file(file) {
            if (confirm("Xac nhan xoa file config " + file)){
                this.location = this.location + "?delete=" + file;
            } 
        }
    </script>';
print '<style>
        table.data    { padding: 0; }
        th.data       { font-size: 12pt; text-align: left; padding: 0 3px 0 3px; border-bottom: 1px solid #777777; color: #333333; }
        .dataOdd      { font-size: 10pt; background-color: #e7e7e7; padding: 0px 4px 0px 4px; }
        .dataEven     { font-size: 10pt; background-color: #f4f2f2; padding: 0px 4px 0px 4px; }
        a             { text-decoration: none;}
    </style>';
print '</head>';
print '<body>';

if ($delete ne ""){
    my $cmd = 'rm /usr/local/nagios/etc/my_config/'.$delete;
    $cmd = `$cmd`;
    $cmd = `sudo systemctl restart nagios`;
    print '<meta http-equiv="refresh" content="0; URL=delete-host.pl">';
}else{
    print '<table width="100%" align="center" class="data">';
    print '<tr><th class="data">Host</th><th class="data">Alias</th><th class="data">Type</th><th class="data">Address</th><th class="data">File config</th><th class="data"></th></tr>';

    if (open (my $f, "<", "/usr/local/nagios/var/objects.cache")){
        my $check = 0;
        my $even = 0;
        my $myhost = host->new();
        while (my $line = <$f>){
            if ($check ==1){
                if ($line =~ /host_name/){
                    my $name = substr($line, 11);
                    chomp($name);
                    $myhost->host_name($name);
                    my $cmd = 'ls /usr/local/nagios/etc/my_config/*'.$name.'.cfg';
                    $cmd = `$cmd`;
                    my $file;
                    my $type;
                    if ($cmd ne ""){
                        $file = substr($cmd, 32);
                        $type = substr($file,0,6);
                        chomp($file);
                        chomp($type);
                        $myhost->file($file);
                        $myhost->type($type);
                    }
                }
                if ($line =~ /alias/){
                    my $alias = substr($line, 7);
                    chomp($alias);
                    $myhost->alias($alias);
                }
                if ($line =~ /address/){
                    my $address = substr($line, 9);
                    chomp($address);
                    $myhost->address($address);
                    $check = 0;
                    print '<tr class="'.(($even % 2)? "dataEven":"dataOdd").'">
                            <td class="'.(($even % 2)? "dataEven":"dataOdd").'"><a href="extinfo.cgi?type=1&host='.$myhost->host_name.'">'.$myhost->host_name.'</td>
                            <td class="'.(($even % 2)? "dataEven":"dataOdd").'">'.$myhost->alias.'</td>
                            <td class="'.(($even % 2)? "dataEven":"dataOdd").'">'.(($myhost->type eq "")? "Unknow":$myhost->type).'</td>
                            <td class="'.(($even % 2)? "dataEven":"dataOdd").'">'.$myhost->address.'</td>
                            <td class="'.(($even % 2)? "dataEven":"dataOdd").'">'.(($myhost->file eq "")? "Unlocated":$myhost->file).'</td>
                            <td align = "center"><input type = "button" value = "Delete" onclick="delete_file(\''.$myhost->file.'\')" '.(($myhost->file eq "")? "disabled":"").'></td>
                        </tr>';
                    $even = ($even + 1) % 2;
                }
            }
            if ($line =~ /define host/){
                $check = 1;
            }
        }
    }
    print '</table>';
}

print '</body>';
print '</html>';