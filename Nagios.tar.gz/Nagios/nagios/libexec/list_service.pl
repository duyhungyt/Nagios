#!/usr/bin/perl -w

use strict;
use Getopt::Long;

my $OK = 0;
my $WARNING = 1;
my $CRITICAL = 2;
my $UNKNOW = 3;
my $service_name = "--status-all";
my $status = "";
my $command = "";
my $serv;
my @list_serv;
my $return;

GetOptions(
        "service|sv=s" => \$service_name,
	"status|s=s" => \$status
);
chomp($service_name);
chomp($status);
	
if ($service_name =~ /--status-all/){

	$return = `service $service_name`;

	if ($status eq ""){
		print $return;
		exit $OK
	}else{
		@list_serv = split(/\n/,$return);
		if ($status =~ /run/){
			foreach $serv (@list_serv){
    				if ($serv =~ /\[ \+ \]/) {
					print($serv, "\n");
   				}
			}	
			exit $OK
		}elsif ($status =~ /stop/){
			foreach $serv (@list_serv){
    				if ($serv =~ /\[ \- \]/) {
					print($serv, "\n");
 	  			}
			}
			exit $OK
		}else{
			print "UNKNOWS";
			exit $UNKNOW
		}
	}
}else{
	$return = `service $service_name status`;
	if ($return =~ /Loaded\: loaded/){
		if ($return =~ /Active\: inactive/){
			print "Service $service_name is stopped";
			exit $CRITICAL
		}elsif ($return =~ /Active\: active/){
			print "Service $service_name is running";
			exit $OK;		
		}elsif ($return =~ / Active\: failed/){
			print "Service $service_name is failed";
			exit $CRITICAL
		}else{
			print "UNKNOW";
			exit $UNKNOW
		}
	}elsif ($return =~ /Loaded\: not-found/){
		print "Service $service_name is not installed";
		exit $CRITICAL
	}else{
		print "UNKNOW";
		exit $UNKNOW
	}
}

