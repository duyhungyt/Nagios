#!/usr/bin/perl -w

use strict;
use Getopt::Long qw(:config no_ignore_case);

my $UNKNOW = 3;
my $OK = 0;
my $WARNING = 1;
my $CRITICAL = 2;
my $host = "127.0.0.1";
my $community = "public";
my $warning = 1000;
my $critical = 2000;
my $interface = "Vlan1";
my $oid="0";
my $MIBifDescr="IF-MIB::ifDescr";
my $MIBifOper="IF-MIB::ifOperStatus";
my $MIBifName="IF-MIB::ifName";
my $MIBTrafficIn="IF-MIB::ifInOctets";
my $MIBTrafficOut="IF-MIB::ifOutOctets";
my $MIBDescription="IF-MIB::ifAlias";
###################Getting options##############################
GetOptions(
    "host|H=s" => \$host,
    "community|C=s"  => \$community,
	"interface|i=s"   => \$interface,
	"warning|w=i" => \$warning,
    "critical|c=i" => \$critical
);
chomp($host);
chomp($community);
chomp($interface);
chomp($warning);
chomp($critical);
#print "$host \n $community \n $interface \n $warning \n $critical \n"; 
#################################################################

if ($warning > $critical){
    print "ERROR: Warning can't be larger then Critical: $warning > $critical";
    exit $CRITICAL;
}
 	
my $walkDescr = snmpwalkgrep($host, $community, $MIBifDescr, $interface);
my $walkName = snmpwalkgrep($host, $community, $MIBifName, $interface);

if ($walkDescr =~ /$interface/ or $walkName =~ /$interface/){
	if ($walkDescr =~ /ifDescr.([0-9]+)/ || $walkName =~ /ifName.([0-9]+)/){
		my $oid =$1;
		#print "$oid\n";
		my $tree="IF-MIB::ifOperStatus.$oid";
		my $return=snmpwalk($host, $community, $tree);
		if ($return =~ /up/){
			my $Alias= snmpwalk($host, $community, "$MIBDescription"."\.".$oid);
            my $AliasCleaned=CleanMe($Alias);
            ##lay thong tin traffic lan 1
            my $Time = snmpwalk($host, $community, "1.3.6.1.6.3.10.2.1.3");
			my $TrafficIn =snmpwalk($host, $community, "$MIBTrafficIn"."\.".$oid);
			my $TrafficOut=snmpwalk($host, $community, "$MIBTrafficOut"."\.".$oid);
			my $TrafficInCleaned=CleanMe($TrafficIn);
			my $TrafficOutCleaned=CleanMe($TrafficOut);
            my $TimeCleaned = CleanMe($Time);
            #print "$TrafficInCleaned $TrafficOutCleaned $TimeCleaned\n";
            sleep(4);
            ##lay thong tin traffic lan 2
            my $NewTime = snmpwalk($host, $community, "1.3.6.1.6.3.10.2.1.3");
            my $NewTrafficIn =snmpwalk($host, $community, "$MIBTrafficIn"."\.".$oid);
			my $NewTrafficOut=snmpwalk($host, $community, "$MIBTrafficOut"."\.".$oid);
			my $NewTrafficInCleaned=CleanMe($NewTrafficIn);
			my $NewTrafficOutCleaned=CleanMe($NewTrafficOut);
            my $NewTimeCleaned=CleanMe($NewTime);
            #print "$NewTrafficInCleaned $NewTrafficOutCleaned $NewTimeCleaned\n";
            ##tinh toan toc do
            my $InSpeed = ($NewTrafficInCleaned - $TrafficInCleaned)/($NewTimeCleaned - $TimeCleaned);
            my $OutSpeed = ($NewTrafficOutCleaned - $TrafficOutCleaned)/($NewTimeCleaned - $TimeCleaned);
            if ($InSpeed > $critical || $OutSpeed > $critical){
                print "CRITICAL!! Traffic over $interface is higher than $critical Bps, Traffic in : $InSpeed Bps, out: $OutSpeed Bps\n";
                exit $CRITICAL;
            }elsif ($InSpeed > $warning || $OutSpeed > $warning){
                print "WARNING!! Traffic over $interface is higher than $warning Bps, Traffic in : $InSpeed Bps, out: $OutSpeed Bps\n";
                exit $WARNING;
            }else{
                print "$interface up: $AliasCleaned, Traffic in : $InSpeed Bps, out: $OutSpeed Bps\n";
			exit $OK;
            }		
		}elsif ($return =~ /down/){
			print "$interface is down\n";
			exit $CRITICAL;
		}elsif($return =~ /dormant/){
			print "Error : $interface is sleeping\n";
			exit $CRITICAL;
		}else{
			print "Unknown state for $interface : check your -s state syntax\n";
			exit $UNKNOW;
		}
		
	}else{
	print "Not supported\n";
	exit $UNKNOW;
	}	
}else{
	print "Interface not found : please check your syntax for this device\n"; 
	exit $UNKNOW;
}

sub CleanMe
{
	my $input=$_[0];
	if ($input =~ /: (.*)/){
	my $return=$1;
	chomp($return);
	return $return;
}


}

sub snmpwalk
{
	my ($host, $community, $tree)=@_;
	my $walk = `snmpwalk -v 1 -c $community $host $tree`;
    #print "snmpwalk -v 1 -c $community $host $tree\n$walk\n";
	chomp($walk);
	return $walk;
}

sub snmpwalkgrep
{
	my ($host, $community, $tree, $interface)=@_;
	my $walk = `snmpwalk -v 1 -c $community $host $tree |grep $interface`;
    #print "snmpwalk -v 1 -c $community $host $tree |grep $interface\n$walk\n";
	chomp($walk);
	return $walk;
}

sub snmpget
{
	my ($host, $community, $tree)=@_;
	my $get = `snmpget -v 1 -c $community $host $tree`;
	chomp($get);
	return $get;
}
