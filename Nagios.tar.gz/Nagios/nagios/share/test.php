<?php?>
<html>
<head>
    <script type="text/javascript" src="/nagios/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="/nagios/js/nag_funcs.js"></script>
    <script type="text/javascript">
            function set_selected() { 
                alert("this works");
                //this.location = url+\'?selected=\'+$(\'#type\').val();
            }
        </script>
</head>
<body>
<form>
<select id="type" onchange="set_selected()" name = "type">
      <option value = "server" selected>Server</option>
      <option value = "switch">Switch</option>
      <option value = "router">Router</option>
   </select>
   </form>
</body>
</html>