<?php
// Allow specifying main window URL for permalinks, etc.
$url1 = 'cgi-bin/add-host-form.pl';
$url2 = 'cgi-bin/save-host.pl';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">

<html>
<head>
	<title>Nagios: <?php echo $_SERVER['SERVER_NAME']; ?></title>
</head>

<frameset cols="40%,*" style="border: 0px; framespacing: 0px">
	<frame src="<?php echo $url1; ?>" name="form" frameborder="0" style="" noresize="noresize">
	<frame src="<?php echo $url2; ?>" name="review" frameborder="0" style="">
</frameset>

</html>
